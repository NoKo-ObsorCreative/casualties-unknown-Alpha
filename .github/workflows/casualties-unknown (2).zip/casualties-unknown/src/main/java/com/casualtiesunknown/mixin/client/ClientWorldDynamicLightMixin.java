package com.casualtiesunknown.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.casualtiesunknown.client.light.DynamicLightManager;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

/**
 * Boosts {@link World#getLightLevel(LightType, BlockPos)} for block light
 * with whatever {@link DynamicLightManager} says should be added at that
 * position. Mixed into {@code World} (rather than {@code ClientWorld}
 * directly) because that's where the method is actually declared in Yarn;
 * the {@code instanceof ClientWorld} guard keeps this from ever touching
 * server-side light calculations, including the integrated server that
 * runs alongside the client in singleplayer.
 *
 * <p>See {@link DynamicLightManager} for the troubleshooting note on this
 * being the most version-fragile file in the project.
 */
@Mixin(World.class)
public abstract class ClientWorldDynamicLightMixin {

	@Inject(method = "getLightLevel(Lnet/minecraft/world/LightType;Lnet/minecraft/util/math/BlockPos;)I",
			at = @At("RETURN"), cancellable = true)
	private void casualtiesunknown$boostDynamicLight(LightType type, BlockPos pos, CallbackInfoReturnable<Integer> cir) {
		if (type != LightType.BLOCK) {
			return;
		}
		if (!(((Object) this) instanceof ClientWorld)) {
			return;
		}
		int extra = DynamicLightManager.getExtraLight(pos);
		if (extra > cir.getReturnValue()) {
			cir.setReturnValue(extra);
		}
	}
}
