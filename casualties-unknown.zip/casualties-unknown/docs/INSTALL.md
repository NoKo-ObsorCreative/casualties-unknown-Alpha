# Installation & Build Guide

## What you need first

- **Java Development Kit (JDK) 21**. Minecraft 1.21.1 + this project's
  Gradle config both require Java 21 specifically -- newer or older JDKs
  can cause confusing build errors.
- An internet connection the *first* time you build (Gradle needs to
  download Minecraft, Yarn mappings, Fabric Loader, and Fabric API). This
  project was assembled in a sandboxed environment with no internet
  access, so none of that has been downloaded or verified here -- your
  first build is the first time these exact dependency versions get
  resolved and compiled together.
- Optionally: IntelliJ IDEA (recommended) or another IDE with Gradle
  support, if you want to browse/edit the code comfortably.

## First-time setup

1. Unzip the project anywhere on your machine.
2. Open a terminal in the project's root folder (the one containing
   `build.gradle`).
3. Generate the Gradle wrapper jar (only `gradle-wrapper.properties` is
   included, not the jar itself, since that's a binary file):
   ```
   gradle wrapper
   ```
   (Requires a system-installed Gradle just for this one step -- see
   https://gradle.org/install/ if you don't have one. After this, every
   command below uses `./gradlew` / `gradlew.bat` and never needs your
   system Gradle again.)
4. Build the mod:
   ```
   ./gradlew build          (macOS/Linux)
   gradlew.bat build        (Windows)
   ```
   The first run will take a while -- it's downloading and setting up the
   whole Minecraft + Fabric development environment.
5. If the build fails with a dependency resolution error, open
   https://fabricmc.net/develop/ and check the current Loader/API/Yarn
   build numbers for Minecraft 1.21.1, then update `gradle.properties` to
   match (Fabric ships new builds often, and the versions in this project
   were current at the time it was generated).
6. If it fails with a **Mixin** error instead, see the "Known risk areas"
   section of `docs/DEVELOPER.md` -- a couple of the mixins target private
   methods whose exact names/signatures can shift between versions and
   are the most likely spot to need a small fix.

## Where the output goes

After a successful build, the finished mod jar is at:
```
build/libs/casualties-unknown-0.1.0.jar
```

## Playing it (singleplayer / your own client)

1. Install the [Fabric Loader installer](https://fabricmc.net/use/installer/)
   for Minecraft 1.21.1.
2. Install the matching [Fabric API](https://modrinth.com/mod/fabric-api)
   mod jar for 1.21.1 into your `.minecraft/mods` folder.
3. Copy `build/libs/casualties-unknown-0.1.0.jar` into the same `mods`
   folder.
4. Launch Minecraft using the "fabric-loader" profile.

## Running a dedicated server

1. Set up a Fabric server for 1.21.1 (the Fabric installer can do this
   with the `-server` flag, or grab the server launcher jar from
   https://fabricmc.net/use/).
2. Put both `fabric-api-*.jar` and `casualties-unknown-0.1.0.jar` in the
   server's `mods` folder.
3. Start the server as normal (`java -jar fabric-server-launch.jar`).
   Everything in this mod is server-authoritative and networked, so it
   works the same in singleplayer, LAN, and dedicated-server play.

## Developing / iterating in an IDE

- IntelliJ IDEA: File -> Open -> select the project folder (the one with
  `build.gradle`) -> let it import as a Gradle project.
- Run `./gradlew genSources` once to get readable (deobfuscated) source
  for Minecraft itself, which is very useful when troubleshooting mixins
  or checking exact method signatures.
- `./gradlew runClient` launches a dev-mode client with the mod loaded.
- `./gradlew runServer` launches a dev-mode dedicated server with the mod
  loaded (first run will ask you to accept the EULA in `run/eula.txt`).

## Adding your own textures/models

See `docs/TEXTURES_AND_MODELS.md` for exactly where to put your art.
