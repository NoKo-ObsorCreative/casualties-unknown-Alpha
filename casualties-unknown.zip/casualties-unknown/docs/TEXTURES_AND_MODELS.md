# Adding Your Own Textures & Models

Every item in this mod currently uses a placeholder model that points at
**vanilla's own Potato texture**, exactly as requested -- so the mod works
and every item is visible in-game the moment you build it, even before you
add any art. This guide shows you exactly which files to replace (and
which new files to add) to give each item real art.

There are three kinds of assets you might want to add:
1. **Item textures + models** (the main ask)
2. **A mod icon** (optional, cosmetic, shown in the mod list)
3. **The music disc's audio + custom GUI icons** (optional extras, same idea)

All paths below are relative to the project root you'll get after
unzipping, i.e. `casualties-unknown/src/main/resources/...`.

---

## 1. Item textures

Put one PNG per item here, using the **exact item id** as the filename:

```
src/main/resources/assets/casualtiesunknown/textures/item/bandage.png
src/main/resources/assets/casualtiesunknown/textures/item/military_bandage.png
src/main/resources/assets/casualtiesunknown/textures/item/splint.png
src/main/resources/assets/casualtiesunknown/textures/item/painkillers.png
src/main/resources/assets/casualtiesunknown/textures/item/disinfectant.png
src/main/resources/assets/casualtiesunknown/textures/item/tourniquet.png
src/main/resources/assets/casualtiesunknown/textures/item/blood_bag.png
src/main/resources/assets/casualtiesunknown/textures/item/saline_iv.png
src/main/resources/assets/casualtiesunknown/textures/item/orange_juice.png
src/main/resources/assets/casualtiesunknown/textures/item/water_bottle.png
src/main/resources/assets/casualtiesunknown/textures/item/antibiotics.png
src/main/resources/assets/casualtiesunknown/textures/item/burn_cream.png
src/main/resources/assets/casualtiesunknown/textures/item/medkit.png
src/main/resources/assets/casualtiesunknown/textures/item/medical_scissors.png
src/main/resources/assets/casualtiesunknown/textures/item/medical_gloves.png
src/main/resources/assets/casualtiesunknown/textures/item/syringe.png
src/main/resources/assets/casualtiesunknown/textures/item/music_disc_placeholder.png
```

That folder doesn't exist yet in the zip (there's nothing in it -- the
placeholder models below point at vanilla's own texture instead, so no
files were needed there at all). **Create the folder and drop your PNGs
in** using the filenames above.

Standard Minecraft item textures are **16x16 pixels**, PNG, with
transparency where needed. They can technically be any power-of-two size
(32x32, 64x64, etc.) and Minecraft will still render them correctly.

---

## 2. Item models

Each item already has a model file here:

```
src/main/resources/assets/casualtiesunknown/models/item/<item_id>.json
```

Right now every one of them looks like this (this is the "use the potato
model for now" placeholder):

```json
{
	"parent": "minecraft:item/generated",
	"textures": {
		"layer0": "minecraft:item/potato"
	}
}
```

**To switch an item over to your own texture**, open its model file and
change `"minecraft:item/potato"` to point at the texture you just added in
step 1. For example, `models/item/bandage.json` becomes:

```json
{
	"parent": "minecraft:item/generated",
	"textures": {
		"layer0": "casualtiesunknown:item/bandage"
	}
}
```

That's it -- no code changes needed. The `"casualtiesunknown:item/bandage"`
path automatically resolves to
`assets/casualtiesunknown/textures/item/bandage.png`.

**If you want a full 3D model** (like a hand-held tool instead of a flat
2D sprite -- Medical Scissors might suit this, for example), replace the
whole file with a real block/item model definition instead of the
`item/generated` flat-sprite parent. The vanilla shears model
(`assets/minecraft/models/item/shears.json` inside the game's own jar,
viewable by opening the Minecraft client jar with any zip tool) is a good
starting reference for a simple 3D handheld tool model.

You only need to touch the models for items you're re-texturing. Any item
you leave alone keeps using the potato placeholder and will keep working
fine.

---

## 3. (Optional) Mod icon

Not required to build or play, but if you want a custom icon in the Mods
list:

1. Add a 128x128 (or any square size) PNG at:
   `src/main/resources/assets/casualtiesunknown/icon.png`
2. Open `src/main/resources/fabric.mod.json` and add this line back in
   (it was left out of the zip specifically because no icon file was
   included):
   ```json
   "icon": "assets/casualtiesunknown/icon.png",
   ```

---

## 4. (Optional) Music disc audio

The Music Disc item is fully wired up (recipe, jukebox support, tooltip),
but it has no actual sound file bundled -- that's audio, not
textures/models, but since it's the other "bring your own asset" case in
this project, it's worth covering here too:

1. Add your `.ogg` audio file at:
   `src/main/resources/assets/casualtiesunknown/sounds/down1.ogg`
2. That's it -- `sounds.json` already points `casualtiesunknown:down1` at
   that exact path, and the disc's jukebox-song data file already
   references that sound event.

---

## 5. (Optional) Custom HUD / GUI icons

The Injuries Menu and the HUD (blood/pain/exhaustion bars, condition
icons) are currently drawn as plain colored rectangles in code -- no
texture files are involved at all, so the mod works with zero GUI art.
If you'd like to reskin them with real icon textures later:

1. Add PNGs under:
   `src/main/resources/assets/casualtiesunknown/textures/gui/`
   (e.g. `bleeding_icon.png`, `fracture_icon.png`, `panel_background.png`)
2. In `src/main/java/com/casualtiesunknown/render/HealthHud.java` and
   `src/main/java/com/casualtiesunknown/gui/InjuriesScreen.java`, replace
   the `context.fill(...)` calls with `context.drawTexture(...)` calls
   pointing at your new textures. This is a code change, not just a
   drop-in file, so it's covered in more depth in `docs/DEVELOPER.md`.

---

## Quick checklist

- [ ] `textures/item/<id>.png` added for each item you want to re-skin
- [ ] matching `models/item/<id>.json` edited to point at it (swap out `minecraft:item/potato`)
- [ ] (optional) `icon.png` added + `fabric.mod.json` updated
- [ ] (optional) `sounds/down1.ogg` added
- [ ] (optional) GUI textures added + `HealthHud.java`/`InjuriesScreen.java` updated to use them

Once your files are in place, rebuild with `./gradlew build` (see
`docs/INSTALL.md`) and everything should pick up automatically -- no other
code changes are required for textures/models.
