Put your item texture PNGs here, named after the item id, e.g.:
  bandage.png
  military_bandage.png
  splint.png
  ...

Then edit the matching file in ../../models/item/<id>.json to point
"layer0" at "casualtiesunknown:item/<id>" instead of "minecraft:item/potato".

Full instructions: docs/TEXTURES_AND_MODELS.md
