Optional: put custom HUD/GUI icon PNGs here (e.g. bleeding_icon.png).

The HUD (render/HealthHud.java) and Injuries Menu (gui/InjuriesScreen.java)
currently draw everything as plain colored shapes in code, so nothing here
is required for the mod to work. See docs/TEXTURES_AND_MODELS.md, section 5,
if you'd like to wire real icon textures in.
