package com.casualtiesunknown.events;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.network.HealthSyncPayload;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Coalesces health-data mutations into at most one sync packet per player
 * per tick, per the "synchronize only changed data" / "minimize packet
 * size" performance requirements. Any code that mutates a player's
 * {@link PlayerHealthData} should call {@link #markDirty(UUID)}; the actual
 * packet is flushed once at the end of the tick loop in
 * {@link ServerTickHandler}.
 */
public final class HealthSyncHelper {

	private static final Set<UUID> DIRTY = ConcurrentHashMap.newKeySet();

	private HealthSyncHelper() {
	}

	public static void markDirty(UUID uuid) {
		DIRTY.add(uuid);
	}

	public static boolean isDirty(UUID uuid) {
		return DIRTY.contains(uuid);
	}

	public static void clearDirty(UUID uuid) {
		DIRTY.remove(uuid);
	}

	/** Sends an unconditional full sync, e.g. on join. Does not touch the dirty flag. */
	public static void sendFullSync(ServerPlayerEntity player, PlayerHealthData data) {
		ServerPlayNetworking.send(player, new HealthSyncPayload(data.toNbt()));
	}

	/** Sends a sync only if this player was marked dirty, then clears the flag. */
	public static void flushIfDirty(ServerPlayerEntity player, PlayerHealthData data) {
		UUID uuid = player.getUuid();
		if (DIRTY.remove(uuid)) {
			ServerPlayNetworking.send(player, new HealthSyncPayload(data.toNbt()));
		}
	}
}
