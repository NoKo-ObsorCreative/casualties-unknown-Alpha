package com.casualtiesunknown.events;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;
import com.casualtiesunknown.effects.BleedingSystem;
import com.casualtiesunknown.effects.ExhaustionSystem;
import com.casualtiesunknown.effects.FractureSystem;
import com.casualtiesunknown.effects.HydrationSystem;
import com.casualtiesunknown.effects.InfectionSystem;
import com.casualtiesunknown.effects.PainSystem;
import com.casualtiesunknown.effects.ShockSystem;
import com.casualtiesunknown.registry.ModAttachmentTypes;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Central per-tick loop. To avoid unnecessary work (see the "Performance"
 * requirement), the once-a-second systems (bleeding, pain, infection,
 * shock, exhaustion, hydration, fractures) only actually run every 20
 * ticks; every tick, we just flush any pending network syncs so combat
 * feels responsive without the medical simulation itself costing anything
 * on the other 19 ticks out of 20.
 */
public final class ServerTickHandler {

	private static final int SYSTEMS_INTERVAL_TICKS = 20;

	private ServerTickHandler() {
	}

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(ServerTickHandler::onEndTick);
	}

	private static void onEndTick(MinecraftServer server) {
		ModConfig config = ModConfig.get();
		boolean runSystems = server.getTicks() % SYSTEMS_INTERVAL_TICKS == 0;

		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			PlayerHealthData data = player.getAttachedOrCreate(ModAttachmentTypes.HEALTH_DATA);

			if (runSystems) {
				BleedingSystem.tick(player, data, config);
				PainSystem.tick(player, data, config);
				FractureSystem.tick(player, data, config);
				ExhaustionSystem.tick(player, data, config);
				HydrationSystem.tick(player, data, config);
				InfectionSystem.tick(player, data, config, player.getRandom());
				ShockSystem.tick(player, data, config);
				HealthSyncHelper.markDirty(player.getUuid());

				if (data.isDead()) {
					player.kill(player.getServerWorld());
				}
			}

			// Defensive top-up in case anything else in the game touched vanilla health.
			if (player.getHealth() < player.getMaxHealth()) {
				player.setHealth(player.getMaxHealth());
			}

			HealthSyncHelper.flushIfDirty(player, data);
		}
	}
}
