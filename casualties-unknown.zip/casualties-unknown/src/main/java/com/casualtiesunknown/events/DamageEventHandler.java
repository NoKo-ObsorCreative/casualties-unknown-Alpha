package com.casualtiesunknown.events;

import java.util.Map;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;
import com.casualtiesunknown.effects.ExhaustionSystem;
import com.casualtiesunknown.effects.ShockSystem;
import com.casualtiesunknown.medical.DamageDistributor;
import com.casualtiesunknown.medical.InjuryApplier;
import com.casualtiesunknown.registry.ModAttachmentTypes;
import com.casualtiesunknown.util.ModConstants;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Intercepts damage <em>after</em> vanilla has already resolved armor,
 * enchantments and shields (via {@code ServerLivingEntityEvents.AFTER_DAMAGE},
 * which hands us the final post-mitigation amount), feeds that amount into
 * {@link DamageDistributor} + {@link InjuryApplier} to update the real
 * (limb-based) health pool, and then tops the player's vanilla health back
 * up so the hidden vanilla hearts never actually change and vanilla never
 * kills the player on its own.
 *
 * <p>Void damage and explicit kills (e.g. {@code /kill}) are deliberately
 * left alone -- see {@link #shouldBypassCustomHandling(DamageSource)} -- so
 * that server operators and game rules relying on those still work exactly
 * like vanilla.
 */
public final class DamageEventHandler {

	private DamageEventHandler() {
	}

	public static void register() {
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (!(entity instanceof ServerPlayerEntity player)) {
				return;
			}
			if (blocked || damageTaken <= 0) {
				return;
			}
			if (shouldBypassCustomHandling(source)) {
				return;
			}

			ModConfig config = ModConfig.get();
			PlayerHealthData data = player.getAttachedOrCreate(ModAttachmentTypes.HEALTH_DATA);

			float scaledAmount = damageTaken * config.difficultyMultiplier;
			DamageDistributor.Category category = DamageDistributor.categorize(source);
			Map<BodyPart, Float> distribution = DamageDistributor.distribute(source, scaledAmount, player.getRandom());
			InjuryApplier.apply(data, category, distribution, player.getRandom());

			ShockSystem.onBurstDamage(data, scaledAmount, config);
			ExhaustionSystem.onCombatAction(data, config);

			HealthSyncHelper.markDirty(player.getUuid());

			// "Interrupt if damaged": stop whatever medical item the player is
			// mid-use of. The client sees this the normal vanilla way (use
			// action cancelled) and closes any open minigame screen on its own
			// -- see the client tick handler.
			if (player.isUsingItem() && player.getActiveItem().getItem() instanceof com.casualtiesunknown.medical.MedicalItem) {
				player.stopUsingItem();
			}

			// Keep vanilla health topped up: our system is the real source of truth,
			// hearts are hidden client-side (see InGameHudMixin), and vanilla death
			// is only ever triggered explicitly below via player.kill(...).
			player.setHealth(player.getMaxHealth());

			if (data.isDead()) {
				player.kill(player.getServerWorld());
			}
		});

		ModConstants.LOGGER.debug("Registered Casualties Unknown damage handler");
	}

	private static boolean shouldBypassCustomHandling(DamageSource source) {
		return source.isOf(DamageTypes.OUT_OF_WORLD)
				|| source.isOf(DamageTypes.GENERIC_KILL)
				|| source.isOf(DamageTypes.FELL_OUT_OF_WORLD);
	}
}
