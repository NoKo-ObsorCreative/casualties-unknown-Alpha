package com.casualtiesunknown.effects;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Slowly eases pain on uninjured parts and drives the camera-wobble /
 * reduced-mining / reduced-attack feedback ("heavy breathing" is left to the
 * client, which plays a breathing sound loop when global pain is high -- see
 * the client HUD renderer).
 */
public final class PainSystem {

	private PainSystem() {
	}

	public static void tick(ServerPlayerEntity player, PlayerHealthData data, ModConfig config) {
		for (BodyPart part : BodyPart.values()) {
			BodyPartData partData = data.part(part);
			if (partData.isUninjured()) {
				partData.setPain(partData.getPain() - 4.0f);
			} else {
				// Injured parts still ease slightly even while hurt, representing the
				// body adjusting -- full relief requires actual treatment.
				partData.setPain(partData.getPain() - 0.5f);
			}
		}

		float pain = data.getGlobalPain();
		if (pain > 70) {
			StatusEffectApplier.applyNausea(player, 2);
			StatusEffectApplier.applyWeakness(player, 2);
			StatusEffectApplier.applyMiningFatigue(player, 2);
		} else if (pain > 40) {
			StatusEffectApplier.applyNausea(player, 0);
			StatusEffectApplier.applyWeakness(player, 1);
			StatusEffectApplier.applyMiningFatigue(player, 0);
		} else if (pain > 15) {
			StatusEffectApplier.applyMiningFatigue(player, 0);
		}
	}
}
