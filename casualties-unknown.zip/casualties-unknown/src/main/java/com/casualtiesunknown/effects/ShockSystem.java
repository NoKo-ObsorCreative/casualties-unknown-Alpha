package com.casualtiesunknown.effects;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.components.ShockLevel;
import com.casualtiesunknown.config.ModConfig;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Shock is triggered by heavy blood loss, large single hits, explosions and
 * gunshot-equivalent wounds. It manifests as blur/tunnel vision and, at its
 * worst, brief fainting (a short forced Blindness+Slowness spike).
 *
 * <p>{@link #onBurstDamage(PlayerHealthData, float, ModConfig)} should be
 * called by the damage event handler for single hits above a threshold, on
 * top of the passive per-second accumulation done here from blood/pain.
 */
public final class ShockSystem {

	private ShockSystem() {
	}

	public static void tick(ServerPlayerEntity player, PlayerHealthData data, ModConfig config) {
		if (!config.enableShock) {
			data.setShock(ShockLevel.NONE);
			return;
		}

		float bloodDeficit = (1.0f - data.getBloodFraction()) * 100f;
		float painContribution = data.getGlobalPain() * 0.4f;
		float passiveTarget = Math.max(bloodDeficit * 0.6f, painContribution);

		if (passiveTarget > data.getShockMeter()) {
			data.addShockMeter((passiveTarget - data.getShockMeter()) * 0.1f);
		} else {
			data.addShockMeter(-1.0f); // slow recovery when conditions improve
		}

		ShockLevel level;
		float meter = data.getShockMeter();
		if (meter >= 75) {
			level = ShockLevel.SEVERE;
		} else if (meter >= 45) {
			level = ShockLevel.MODERATE;
		} else if (meter >= 20) {
			level = ShockLevel.MILD;
		} else {
			level = ShockLevel.NONE;
		}
		data.setShock(level);

		switch (level) {
			case SEVERE -> {
				StatusEffectApplier.applyBlindness(player, 0);
				StatusEffectApplier.applyNausea(player, 2);
				StatusEffectApplier.applySlowness(player, 3);
			}
			case MODERATE -> {
				StatusEffectApplier.applyNausea(player, 1);
				StatusEffectApplier.applySlowness(player, 1);
			}
			case MILD -> StatusEffectApplier.applyNausea(player, 0);
			case NONE -> {
				// no forced effect; other systems may still apply their own
			}
		}
	}

	/** Called on single hits above a pain/damage threshold for an immediate shock spike. */
	public static void onBurstDamage(PlayerHealthData data, float amount, ModConfig config) {
		if (!config.enableShock) {
			return;
		}
		if (amount >= 12.0f) {
			data.addShockMeter(amount * 0.8f);
		}
	}
}
