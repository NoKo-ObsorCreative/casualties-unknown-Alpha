package com.casualtiesunknown.effects;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Drains blood volume from active bleeding wounds and drives the
 * blur/slowness/darkening feedback as blood volume falls. Runs once per
 * second (see com.casualtiesunknown.events.ServerTickHandler) rather than
 * every tick to keep the cost negligible on busy servers.
 */
public final class BleedingSystem {

	private BleedingSystem() {
	}

	public static void tick(ServerPlayerEntity player, PlayerHealthData data, ModConfig config) {
		if (!config.enableBlood) {
			return;
		}

		float totalLossPerSecond = 0;
		for (BodyPart part : BodyPart.values()) {
			BodyPartData partData = data.part(part);
			if (partData.getBleeding().isBleeding()) {
				totalLossPerSecond += partData.getBleeding().getBloodLossPerSecond();
				// Bleeding wounds keep contributing local pain while active.
				partData.addPain(1.0f);
			}
		}

		if (totalLossPerSecond > 0) {
			data.addBlood(-totalLossPerSecond * config.bloodLossRateMultiplier);
		}

		applyBloodLossFeedback(player, data);
	}

	private static void applyBloodLossFeedback(ServerPlayerEntity player, PlayerHealthData data) {
		float fraction = data.getBloodFraction();

		if (fraction < 0.15f) {
			data.setCollapsed(true);
			StatusEffectApplier.applyBlindness(player, 0);
			StatusEffectApplier.applySlowness(player, 5);
			StatusEffectApplier.applyWeakness(player, 3);
			StatusEffectApplier.applyNausea(player, 2);
		} else if (fraction < 0.35f) {
			data.setCollapsed(false);
			StatusEffectApplier.applySlowness(player, 2);
			StatusEffectApplier.applyNausea(player, 1);
			StatusEffectApplier.applyWeakness(player, 1);
		} else if (fraction < 0.6f) {
			data.setCollapsed(false);
			StatusEffectApplier.applySlowness(player, 0);
			StatusEffectApplier.applyNausea(player, 0);
		} else {
			data.setCollapsed(false);
		}

		if (data.getBloodMl() <= 0) {
			player.kill();
		}
	}
}
