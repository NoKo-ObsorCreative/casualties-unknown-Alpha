package com.casualtiesunknown.effects;

import net.minecraft.util.math.random.Random;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.config.ModConfig;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Untreated lacerations, gunshot wounds and burns can seed an infection,
 * which then grows over time unless treated with Disinfectant/Antibiotics.
 * A fully infected part causes periodic damage, extra pain, reduced stamina
 * and a fever overlay (surfaced to the client via temperature).
 */
public final class InfectionSystem {

	private static final float GROWTH_PER_SECOND = 0.35f;
	private static final float PERIODIC_DAMAGE = 1.0f;

	private InfectionSystem() {
	}

	public static void tick(ServerPlayerEntity player, PlayerHealthData data, ModConfig config, Random random) {
		if (!config.enableInfection) {
			return;
		}

		boolean anyInfected = false;
		for (BodyPart part : BodyPart.values()) {
			BodyPartData partData = data.part(part);

			boolean hasOpenWound = partData.hasLaceration() || partData.getGunshotWounds() > 0 || partData.getBurn().isBurned();
			if (partData.getInfection() <= 0 && hasOpenWound) {
				float seedChance = partData.getBurn().infectionSeedChance()
						+ (partData.hasLaceration() ? 0.004f : 0)
						+ (partData.getGunshotWounds() > 0 ? 0.006f : 0);
				if (isWearingMedicalGloves(player)) {
					seedChance *= com.casualtiesunknown.items.MedicalGlovesItem.SEED_CHANCE_MULTIPLIER;
				}
				if (random.nextFloat() < seedChance) {
					partData.setInfection(1.0f);
				}
			} else if (partData.getInfection() > 0 && partData.getInfection() < 100 && hasOpenWound) {
				partData.setInfection(partData.getInfection() + GROWTH_PER_SECOND);
			}

			if (partData.isInfected()) {
				anyInfected = true;
				partData.damage(PERIODIC_DAMAGE);
				partData.addPain(2.0f);
				data.addExhaustion(1.0f * config.exhaustionRateMultiplier);
			}
		}

		if (anyInfected) {
			data.setTemperatureC(Math.min(40.5f, data.getTemperatureC() + 0.05f));
			StatusEffectApplier.applyNausea(player, 1);
			StatusEffectApplier.applyWeakness(player, 1);
		} else if (data.getTemperatureC() > PlayerHealthData.NORMAL_BODY_TEMP_C) {
			data.setTemperatureC(Math.max(PlayerHealthData.NORMAL_BODY_TEMP_C, data.getTemperatureC() - 0.1f));
		}
	}

	private static boolean isWearingMedicalGloves(ServerPlayerEntity player) {
		return player.getOffHandStack().getItem() instanceof com.casualtiesunknown.items.MedicalGlovesItem;
	}
}
