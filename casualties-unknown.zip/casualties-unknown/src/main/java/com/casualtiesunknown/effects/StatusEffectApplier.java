package com.casualtiesunknown.effects;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Small helper for driving vanilla status effects (Slowness, Nausea,
 * Mining Fatigue, Weakness, Blindness) from our own condition severities.
 *
 * <p>We deliberately reuse these vanilla effects as the "renderer" for pain,
 * blood loss and shock (camera wobble via Nausea, tunnel vision via
 * Blindness, sluggishness via Slowness/Mining Fatigue/Weakness) instead of
 * writing custom camera mixins. It is a proven, stable mechanic and keeps
 * this system from depending on low-level renderer internals that change
 * often between Minecraft versions.
 *
 * <p>Effects are re-applied every check with a short duration (see
 * {@link #REFRESH_DURATION_TICKS}) and {@code showParticles=false},
 * {@code ambient=true} so they don't spam the HUD with vanilla potion icons
 * (the mod's own HUD shows the real condition icons instead).
 */
public final class StatusEffectApplier {

	private static final int REFRESH_DURATION_TICKS = 40; // 2 seconds; refreshed well before it can expire

	private StatusEffectApplier() {
	}

	public static void apply(ServerPlayerEntity player, RegistryEntry<net.minecraft.entity.effect.StatusEffect> effect, int amplifier) {
		if (amplifier < 0) {
			return;
		}
		player.addStatusEffect(new StatusEffectInstance(effect, REFRESH_DURATION_TICKS, amplifier, true, false, false));
	}

	public static void applyNausea(ServerPlayerEntity player, int amplifier) {
		apply(player, StatusEffects.NAUSEA, amplifier);
	}

	public static void applySlowness(ServerPlayerEntity player, int amplifier) {
		apply(player, StatusEffects.SLOWNESS, amplifier);
	}

	public static void applyMiningFatigue(ServerPlayerEntity player, int amplifier) {
		apply(player, StatusEffects.MINING_FATIGUE, amplifier);
	}

	public static void applyWeakness(ServerPlayerEntity player, int amplifier) {
		apply(player, StatusEffects.WEAKNESS, amplifier);
	}

	public static void applyBlindness(ServerPlayerEntity player, int amplifier) {
		apply(player, StatusEffects.BLINDNESS, amplifier);
	}

	public static void applyDarkness(ServerPlayerEntity player, int amplifier) {
		apply(player, StatusEffects.DARKNESS, amplifier);
	}
}
