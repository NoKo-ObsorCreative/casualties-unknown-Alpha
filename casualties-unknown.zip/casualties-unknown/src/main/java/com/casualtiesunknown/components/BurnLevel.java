package com.casualtiesunknown.components;

/** Severity of burns on a body part. Untreated burns can seed infection over time. */
public enum BurnLevel {
	NONE,
	MINOR,
	MODERATE,
	SEVERE,
	CRITICAL;

	public BurnLevel worsen() {
		return values()[Math.min(ordinal() + 1, values().length - 1)];
	}

	public BurnLevel improve() {
		return values()[Math.max(ordinal() - 1, 0)];
	}

	public boolean isBurned() {
		return this != NONE;
	}

	/** Chance per tick-check that an untreated burn of this severity seeds an infection. */
	public float infectionSeedChance() {
		return switch (this) {
			case NONE -> 0.0f;
			case MINOR -> 0.0025f;
			case MODERATE -> 0.006f;
			case SEVERE -> 0.012f;
			case CRITICAL -> 0.02f;
		};
	}
}
