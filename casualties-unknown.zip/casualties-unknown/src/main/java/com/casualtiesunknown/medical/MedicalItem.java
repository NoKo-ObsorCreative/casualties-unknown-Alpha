package com.casualtiesunknown.medical;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.events.HealthSyncHelper;
import com.casualtiesunknown.registry.ModAttachmentTypes;
import com.casualtiesunknown.util.ModConstants;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.UseAction;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * Base class for every medical/treatment item. Handles the common
 * "press and hold, show a progress bar, interrupt if damaged" mechanic
 * described in the spec by riding on vanilla's own item-use-duration
 * system (the same mechanic vanilla uses for eating/drawing a bow), rather
 * than reinventing it. The progress bar itself is drawn by
 * {@link com.casualtiesunknown.render.HealthHud} client-side, reading
 * {@code player.getItemUseTime()} / {@link #getMaxUseTime}.
 *
 * <p>Two use modes are supported:
 * <ul>
 *   <li><b>Simple items</b> (Painkillers, Orange Juice, Water Bottle,
 *   Disinfectant, Antibiotics, Blood Bag, Saline IV, Tourniquet, Burn
 *   Cream, Syringe, Medical Scissors/Gloves): {@link #hasMinigame()} is
 *   false, {@link #applyTreatment(ServerPlayerEntity, float)} is called
 *   directly on the server the moment the hold finishes, with quality
 *   fixed at 1.0.</li>
 *   <li><b>Minigame items</b> (Bandage, Military Bandage, Splint, Medkit):
 *   {@link #hasMinigame()} is true. When the hold finishes on the client,
 *   {@link #MINIGAME_LAUNCHER} (set by the client entrypoint, null on a
 *   dedicated server) opens the timing-bar minigame; its result is sent to
 *   the server as a {@link com.casualtiesunknown.network.TreatmentResultPayload},
 *   which is what actually triggers {@link #applyTreatment}.</li>
 * </ul>
 */
public abstract class MedicalItem extends Item {

	/**
	 * Set by the client entrypoint to open the minigame screen. Declared with
	 * only common-code types in its signature so this class never needs to
	 * resolve any client-only class on a dedicated server -- see the class
	 * javadoc.
	 */
	public static MinigameLauncher MINIGAME_LAUNCHER;

	@FunctionalInterface
	public interface MinigameLauncher {
		void launch(Identifier itemId);
	}

	public MedicalItem(Settings settings) {
		super(settings);
	}

	/** How long (in ticks) the player must hold right-click for this item. */
	public abstract int getUseDurationTicks();

	/** Whether finishing the hold opens a client-side precision minigame before applying the effect. */
	public boolean hasMinigame() {
		return false;
	}

	/** Whether this item is consumed (count -1) after a successful non-minigame use. Durable tools like Medical Scissors override this to false. */
	public boolean isConsumable() {
		return true;
	}

	/**
	 * Applies this item's medical effect on the server. {@code quality} is
	 * 0-1, always 1.0 for non-minigame items, and the minigame score (bandage
	 * pressure timing etc.) for minigame items.
	 */
	public abstract void applyTreatment(ServerPlayerEntity player, float quality);

	@Override
	public int getMaxUseTime(ItemStack stack, LivingEntity user) {
		return getUseDurationTicks();
	}

	@Override
	public UseAction getUseAction(ItemStack stack) {
		return UseAction.BOW;
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		user.setCurrentHand(hand);
		return TypedActionResult.consume(stack);
	}

	@Override
	public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
		if (!(user instanceof ServerPlayerEntity player)) {
			// Client side: either launch the minigame, or just let the simple-item
			// path fall through (the server is what actually applies the effect).
			if (hasMinigame() && MINIGAME_LAUNCHER != null) {
				MINIGAME_LAUNCHER.launch(getRegistryId(stack));
			}
			return stack;
		}

		if (!hasMinigame()) {
			applyTreatment(player, 1.0f);
			if (isConsumable()) {
				consumeOne(stack, player);
			}
		}
		// Minigame items are consumed/applied when the TreatmentResultPayload
		// arrives (see com.casualtiesunknown.network.ModNetworking), since the
		// server has no line of sight into the client-side minigame otherwise.
		return stack;
	}

	private Identifier getRegistryId(ItemStack stack) {
		return net.minecraft.registry.Registries.ITEM.getId(stack.getItem());
	}

	public static void consumeOne(ItemStack stack, ServerPlayerEntity player) {
		if (!player.getAbilities().creativeMode) {
			stack.decrement(1);
		}
	}

	/** Small shared helper so every item plays a consistent "treatment applied" sound. */
	protected void playTreatmentSound(ServerPlayerEntity player) {
		player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ITEM_BUNDLE_INSERT,
				SoundCategory.PLAYERS, 0.6f, 1.1f);
	}

	protected PlayerHealthData dataOf(ServerPlayerEntity player) {
		return player.getAttachedOrCreate(ModAttachmentTypes.HEALTH_DATA);
	}

	protected void syncAndCheckDeath(ServerPlayerEntity player, PlayerHealthData data) {
		HealthSyncHelper.markDirty(player.getUuid());
		if (data.isDead()) {
			player.kill(player.getServerWorld());
		}
	}

	static {
		ModConstants.LOGGER.debug("MedicalItem base class loaded");
	}
}
