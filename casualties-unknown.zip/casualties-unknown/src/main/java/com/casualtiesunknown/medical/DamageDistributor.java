package com.casualtiesunknown.medical;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.util.math.random.Random;

import com.casualtiesunknown.components.BodyPart;

import net.minecraft.entity.damage.DamageSource;
import net.minecraft.registry.tag.DamageTypeTags;

/**
 * Decides how a vanilla {@link DamageSource} + amount translates into
 * per-body-part damage, per the spec:
 * <ul>
 *   <li>Arrow/projectile hits -&gt; a single limb (mostly)</li>
 *   <li>Explosions -&gt; every part takes damage</li>
 *   <li>Falls -&gt; mostly legs</li>
 *   <li>Fire -&gt; entire body</li>
 *   <li>Everything else (melee, magic, generic, etc.) -&gt; weighted single/double part hit</li>
 * </ul>
 */
public final class DamageDistributor {

	private DamageDistributor() {
	}

	public enum Category {
		PROJECTILE,
		EXPLOSION,
		FALL,
		FIRE,
		MELEE,
		GENERIC
	}

	public static Category categorize(DamageSource source) {
		if (source.isIn(DamageTypeTags.IS_EXPLOSION)) {
			return Category.EXPLOSION;
		}
		if (source.isIn(DamageTypeTags.IS_FALL)) {
			return Category.FALL;
		}
		if (source.isIn(DamageTypeTags.IS_FIRE)) {
			return Category.FIRE;
		}
		if (source.isIn(DamageTypeTags.IS_PROJECTILE)) {
			return Category.PROJECTILE;
		}
		if (source.getSource() != null || source.getAttacker() != null) {
			return Category.MELEE;
		}
		return Category.GENERIC;
	}

	/**
	 * Returns a map of body part -> damage amount for the given source/amount.
	 * The values sum to (very close to) {@code amount}.
	 */
	public static Map<BodyPart, Float> distribute(DamageSource source, float amount, Random random) {
		Category category = categorize(source);
		Map<BodyPart, Float> result = new EnumMap<>(BodyPart.class);

		switch (category) {
			case EXPLOSION -> {
				// Every part takes damage, weighted slightly toward the torso.
				float torsoShare = amount * 0.30f;
				float headShare = amount * 0.15f;
				float limbShare = (amount - torsoShare - headShare) / 4.0f;
				result.put(BodyPart.TORSO, torsoShare);
				result.put(BodyPart.HEAD, headShare);
				result.put(BodyPart.LEFT_ARM, limbShare);
				result.put(BodyPart.RIGHT_ARM, limbShare);
				result.put(BodyPart.LEFT_LEG, limbShare);
				result.put(BodyPart.RIGHT_LEG, limbShare);
			}
			case FALL -> {
				float legShare = amount * 0.35f;
				float torsoShare = amount * 0.25f;
				result.put(BodyPart.LEFT_LEG, legShare);
				result.put(BodyPart.RIGHT_LEG, legShare);
				result.put(BodyPart.TORSO, torsoShare);
			}
			case FIRE -> {
				// Spread evenly across the whole body.
				float each = amount / 6.0f;
				for (BodyPart part : BodyPart.values()) {
					result.put(part, each);
				}
			}
			case PROJECTILE -> {
				BodyPart hit = weightedRandomPart(random);
				result.put(hit, amount);
			}
			case MELEE, GENERIC -> {
				// Mostly torso, sometimes a limb or the head.
				BodyPart hit = weightedRandomPart(random);
				result.put(hit, amount);
			}
		}
		return result;
	}

	/**
	 * Weighted single-part pick: torso is the biggest target, head is
	 * smallest, arms/legs share the rest -- roughly proportional to
	 * silhouette area.
	 */
	private static BodyPart weightedRandomPart(Random random) {
		float roll = random.nextFloat() * 100f;
		if (roll < 10f) {
			return BodyPart.HEAD;
		} else if (roll < 45f) {
			return BodyPart.TORSO;
		} else if (roll < 60f) {
			return BodyPart.LEFT_ARM;
		} else if (roll < 75f) {
			return BodyPart.RIGHT_ARM;
		} else if (roll < 90f) {
			return BodyPart.LEFT_LEG;
		} else {
			return BodyPart.RIGHT_LEG;
		}
	}
}
