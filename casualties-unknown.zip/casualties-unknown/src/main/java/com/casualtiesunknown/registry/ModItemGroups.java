package com.casualtiesunknown.registry;

import com.casualtiesunknown.util.ModConstants;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItemGroups {

	public static ItemGroup MEDICAL_GROUP;

	private ModItemGroups() {
	}

	public static void register() {
		MEDICAL_GROUP = Registry.register(
				Registries.ITEM_GROUP,
				ModConstants.id("medical"),
				FabricItemGroup.builder()
						.displayName(Text.translatable("itemGroup.casualtiesunknown.medical"))
						.icon(() -> new ItemStack(ModItems.MEDKIT))
						.entries((context, entries) -> {
							entries.add(ModItems.BANDAGE);
							entries.add(ModItems.MILITARY_BANDAGE);
							entries.add(ModItems.SPLINT);
							entries.add(ModItems.PAINKILLERS);
							entries.add(ModItems.DISINFECTANT);
							entries.add(ModItems.TOURNIQUET);
							entries.add(ModItems.BLOOD_BAG);
							entries.add(ModItems.SALINE_IV);
							entries.add(ModItems.ORANGE_JUICE);
							entries.add(ModItems.ANTIBIOTICS);
							entries.add(ModItems.BURN_CREAM);
							entries.add(ModItems.MEDKIT);
							entries.add(ModItems.MEDICAL_SCISSORS);
							entries.add(ModItems.MEDICAL_GLOVES);
							entries.add(ModItems.SYRINGE);
							entries.add(ModItems.MUSIC_DISC_PLACEHOLDER);
						})
						.build()
		);
	}
}
