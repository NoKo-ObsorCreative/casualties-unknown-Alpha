package com.casualtiesunknown.registry;

import com.casualtiesunknown.util.ModConstants;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;

/**
 * Registers custom sound events. The actual audio file (an .ogg) is NOT
 * included in this project -- see docs/TEXTURES_AND_MODELS.md (also covers
 * sounds) for exactly where to drop {@code down1.ogg}.
 */
public final class ModSounds {

	public static final SoundEvent MUSIC_DISC_PLACEHOLDER =
			SoundEvent.of(ModConstants.id("music_disc.placeholder"));

	private ModSounds() {
	}

	public static void register() {
		Registry.register(Registries.SOUND_EVENT, ModConstants.id("music_disc.placeholder"), MUSIC_DISC_PLACEHOLDER);
	}
}
