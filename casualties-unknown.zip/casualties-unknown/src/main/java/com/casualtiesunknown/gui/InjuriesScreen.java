package com.casualtiesunknown.gui;

import java.util.LinkedHashMap;
import java.util.Map;

import com.casualtiesunknown.client.ClientHealthCache;
import com.casualtiesunknown.client.network.ClientNetworking;
import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * The "press M" Injuries Menu. Shows all six body parts in a simple
 * anatomical layout (head above torso, arms either side, legs below),
 * each part's HP and full injury status, plus body-wide vitals along the
 * bottom. Clicking "Focus" on a part tells the server to target that part
 * with the next treatment item (see TreatmentTargets on the server).
 */
public class InjuriesScreen extends Screen {

	private static final int PANEL_W = 148;
	private static final int PANEL_H = 108;
	private static final int BG = 0xE6141414;
	private static final int PANEL_BG = 0xF0202225;
	private static final int PANEL_BORDER = 0xFF3A3D42;
	private static final int ACCENT = 0xFF8FD3FE;

	public InjuriesScreen() {
		super(Text.translatable("gui.casualtiesunknown.injuries_menu.title"));
	}

	@Override
	protected void init() {
		super.init();
		int centerX = this.width / 2;
		int topY = 30;

		layoutPart(BodyPart.HEAD, centerX - PANEL_W / 2, topY);
		layoutPart(BodyPart.LEFT_ARM, centerX - PANEL_W - PANEL_W / 2 - 10, topY + PANEL_H + 12);
		layoutPart(BodyPart.TORSO, centerX - PANEL_W / 2, topY + PANEL_H + 12);
		layoutPart(BodyPart.RIGHT_ARM, centerX + PANEL_W / 2 + 10, topY + PANEL_H + 12);
		layoutPart(BodyPart.LEFT_LEG, centerX - PANEL_W - 5, topY + (PANEL_H + 12) * 2);
		layoutPart(BodyPart.RIGHT_LEG, centerX + 5, topY + (PANEL_H + 12) * 2);
	}

	private void layoutPart(BodyPart part, int x, int y) {
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.casualtiesunknown.injuries_menu.focus"),
						button -> {
							ClientHealthCache.setUiFocusedPart(part);
							ClientNetworking.sendFocusTarget(part);
						})
				.dimensions(x + PANEL_W - 54, y + PANEL_H - 22, 50, 18)
				.build());
		partOrigins.put(part, new int[] {x, y});
	}

	private final Map<BodyPart, int[]> partOrigins = new LinkedHashMap<>();

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		context.fill(0, 0, this.width, this.height, BG);

		PlayerHealthData data = ClientHealthCache.get();

		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFF);

		for (Map.Entry<BodyPart, int[]> entry : partOrigins.entrySet()) {
			drawPartPanel(context, entry.getKey(), data.part(entry.getKey()), entry.getValue()[0], entry.getValue()[1],
					entry.getKey() == ClientHealthCache.getUiFocusedPart());
		}

		drawVitalsFooter(context, data);

		super.render(context, mouseX, mouseY, delta);
	}

	private void drawPartPanel(DrawContext context, BodyPart part, BodyPartData partData, int x, int y, boolean focused) {
		context.fill(x, y, x + PANEL_W, y + PANEL_H, PANEL_BG);
		int borderColor = focused ? ACCENT : PANEL_BORDER;
		context.drawBorder(x, y, PANEL_W, PANEL_H, borderColor);

		int textX = x + 6;
		int textY = y + 6;
		int lineHeight = 10;

		context.drawText(this.textRenderer, Text.translatable("gui.casualtiesunknown.bodypart." + part.getKey())
				.formatted(Formatting.BOLD), textX, textY, 0xFFFFFF, false);
		textY += lineHeight + 2;

		int hpColor = partData.getHpFraction() > 0.5f ? 0xFF7CFC8A : (partData.getHpFraction() > 0.2f ? 0xFFF2C744 : 0xFFFF6B6B);
		context.drawText(this.textRenderer, Text.literal(String.format("%s: %.0f / %.0f",
				Text.translatable("gui.casualtiesunknown.injuries_menu.hp").getString(),
				partData.getCurrentHp(), partData.getMaxHp())), textX, textY, hpColor, false);
		textY += lineHeight;

		textY = drawLine(context, textX, textY, "gui.casualtiesunknown.injuries_menu.bleeding",
				Text.translatable("level.casualtiesunknown.bleeding." + partData.getBleeding().name().toLowerCase()).getString(),
				partData.getBleeding().isBleeding());
		textY = drawLine(context, textX, textY, "gui.casualtiesunknown.injuries_menu.fracture",
				partData.isFractured() ? "Yes" : "No", partData.isFractured());
		textY = drawLine(context, textX, textY, "gui.casualtiesunknown.injuries_menu.infection",
				partData.isInfected() ? "Infected" : (partData.getInfection() > 0 ? "Developing" : "No"), partData.getInfection() > 0);
		textY = drawLine(context, textX, textY, "gui.casualtiesunknown.injuries_menu.burn",
				partData.getBurn().name(), partData.getBurn().isBurned());
		textY = drawLine(context, textX, textY, "gui.casualtiesunknown.injuries_menu.pain",
				String.format("%.0f", partData.getPain()), partData.getPain() > 30);
	}

	private int drawLine(DrawContext context, int x, int y, String labelKey, String value, boolean bad) {
		String text = Text.translatable(labelKey).getString() + ": " + value;
		context.drawText(this.textRenderer, Text.literal(text), x, y, bad ? 0xFFFF8080 : 0xFFB0B0B0, false);
		return y + 10;
	}

	private void drawVitalsFooter(DrawContext context, PlayerHealthData data) {
		int y = this.height - 28;
		int x = 12;
		String vitals = String.format(
				"Blood: %.0f/%.0f   Pain: %.0f   Exhaustion: %.0f   Hydration: %.0f   Temp: %.1fC   Shock: %s",
				data.getBloodMl(), PlayerHealthData.MAX_BLOOD_ML, data.getGlobalPain(), data.getExhaustion(),
				data.getHydration(), data.getTemperatureC(), data.getShock().name());
		context.fill(0, y - 6, this.width, this.height, 0xF0101010);
		context.drawText(this.textRenderer, Text.literal(vitals), x, y, 0xFFDDDDDD, false);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
