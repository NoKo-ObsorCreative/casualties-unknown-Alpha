package com.casualtiesunknown.gui;

import com.casualtiesunknown.client.network.ClientNetworking;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * The "timing bar" treatment minigame: a marker sweeps back and forth
 * across a bar, and clicking (or pressing space) while it's inside the
 * green target zone scores well. Distance from dead-center maps linearly
 * to a 0-1 quality score sent back to the server.
 *
 * <p>This is intentionally the one minigame type implemented in full --
 * see docs/DEVELOPER.md for how to add the other minigame styles the spec
 * mentions (moving cursor, precision click, pattern memory) using the same
 * "resolve a 0-1 quality, then call ClientNetworking.sendTreatmentResult"
 * pattern.
 */
public class TreatmentMinigameScreen extends Screen {

	private static final int BAR_WIDTH = 220;
	private static final int BAR_HEIGHT = 18;
	private static final float SWEEP_SPEED = 2.2f; // full widths per second

	private final Identifier itemId;
	private float sweepPosition; // 0-1
	private boolean sweepingRight = true;
	private boolean resolved;

	public TreatmentMinigameScreen(Identifier itemId) {
		super(Text.translatable("gui.casualtiesunknown.minigame.title"));
		this.itemId = itemId;
	}

	public static void open(Identifier itemId) {
		MinecraftClient.getInstance().setScreen(new TreatmentMinigameScreen(itemId));
	}

	@Override
	protected void init() {
		super.init();
		this.sweepPosition = 0f;
		this.sweepingRight = true;
		this.resolved = false;
	}

	@Override
	public void tick() {
		super.tick();
		if (resolved) {
			return;
		}
		float delta = SWEEP_SPEED / 20.0f; // per tick, at 20 tps
		if (sweepingRight) {
			sweepPosition += delta;
			if (sweepPosition >= 1f) {
				sweepPosition = 1f;
				sweepingRight = false;
			}
		} else {
			sweepPosition -= delta;
			if (sweepPosition <= 0f) {
				sweepPosition = 0f;
				sweepingRight = true;
			}
		}
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_SPACE) {
			resolve();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		resolve();
		return true;
	}

	private void resolve() {
		if (resolved) {
			return;
		}
		resolved = true;
		float distanceFromCenter = Math.abs(sweepPosition - 0.5f) * 2.0f; // 0 = perfect center, 1 = edge
		float quality = Math.max(0f, 1.0f - distanceFromCenter);
		ClientNetworking.sendTreatmentResult(itemId, quality);
		this.close();
	}

	@Override
	public void close() {
		if (!resolved) {
			// Player closed the screen (e.g. pressed Escape) without committing --
			// treat it as a failed attempt so the item is still consumed server-side
			// with zero effect, consistent with a real interrupted treatment.
			resolved = true;
			ClientNetworking.sendTreatmentResult(itemId, 0.0f);
		}
		super.close();
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		context.fill(0, 0, this.width, this.height, 0x66000000);

		int barX = this.width / 2 - BAR_WIDTH / 2;
		int barY = this.height / 2;

		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, barY - 40, 0xFFFFFF);
		context.drawCenteredTextWithShadow(this.textRenderer,
				Text.translatable("gui.casualtiesunknown.minigame.instructions"), this.width / 2, barY - 26, 0xCCCCCC);

		context.fill(barX, barY, barX + BAR_WIDTH, barY + BAR_HEIGHT, 0xFF202225);
		context.drawBorder(barX, barY, BAR_WIDTH, BAR_HEIGHT, 0xFF3A3D42);

		int targetWidth = BAR_WIDTH / 5;
		int targetX = barX + BAR_WIDTH / 2 - targetWidth / 2;
		context.fill(targetX, barY, targetX + targetWidth, barY + BAR_HEIGHT, 0x8850C878);

		int markerX = barX + Math.round(sweepPosition * BAR_WIDTH);
		context.fill(markerX - 1, barY - 4, markerX + 2, barY + BAR_HEIGHT + 4, 0xFFFFFFFF);

		super.render(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return true;
	}
}
