package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.medical.TreatmentTargets;

import net.minecraft.server.network.ServerPlayerEntity;

/** Reduces the severity of the worst burn on the body and eases the associated pain. */
public class BurnCreamItem extends MedicalItem {

	public BurnCreamItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 30;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		BodyPart target = TreatmentTargets.resolve(player.getUuid(), data, TreatmentTargets::autoPickBurn);
		BodyPartData partData = data.part(target);

		if (quality >= 0.4f) {
			partData.setBurn(partData.getBurn().improve());
		}
		partData.addPain(-8.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
