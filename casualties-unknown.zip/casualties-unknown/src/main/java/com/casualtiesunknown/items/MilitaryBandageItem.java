package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.medical.TreatmentTargets;

import net.minecraft.server.network.ServerPlayerEntity;

/** Faster and more effective than a regular Bandage, and can partially address internal bleeding. */
public class MilitaryBandageItem extends MedicalItem {

	public MilitaryBandageItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 25;
	}

	@Override
	public boolean hasMinigame() {
		return true;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		BodyPart target = TreatmentTargets.resolve(player.getUuid(), data, TreatmentTargets::autoPickBleeding);
		BodyPartData partData = data.part(target);

		if (quality >= 0.6f) {
			partData.setBleeding(com.casualtiesunknown.components.BleedingLevel.NONE);
		} else if (quality >= 0.25f) {
			partData.setBleeding(partData.getBleeding().improve().improve());
		} else {
			partData.setBleeding(partData.getBleeding().improve());
		}

		if (quality >= 0.7f) {
			partData.setInternalBleeding(false);
		}

		partData.heal(7.0f * quality);
		partData.addPain(-8.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
