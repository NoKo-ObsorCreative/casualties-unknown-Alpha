package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.medical.TreatmentTargets;

import net.minecraft.server.network.ServerPlayerEntity;

/** Splints a fractured limb. A poor minigame result still eases pain but leaves the fracture in place. */
public class SplintItem extends MedicalItem {

	public SplintItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 60;
	}

	@Override
	public boolean hasMinigame() {
		return true;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		BodyPart target = TreatmentTargets.resolve(player.getUuid(), data, TreatmentTargets::autoPickFracture);
		BodyPartData partData = data.part(target);

		if (quality >= 0.5f) {
			partData.setFractured(false);
		}
		partData.addPain(-10.0f * quality - 2.0f);
		partData.heal(3.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
