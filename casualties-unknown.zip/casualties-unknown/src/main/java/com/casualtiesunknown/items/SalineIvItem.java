package com.casualtiesunknown.items;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/** A saline IV can't replace lost blood cells the way a Blood Bag can, but it restores volume and hydration quickly. */
public class SalineIvItem extends MedicalItem {

	public SalineIvItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 80;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		data.addBlood(700.0f * quality);
		data.addHydration(30.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
