package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/**
 * The most comprehensive treatment item: long use duration, one minigame
 * attempt, but on success it improves bleeding, heals HP and eases pain
 * across every body part at once instead of just the worst one.
 */
public class MedkitItem extends MedicalItem {

	public MedkitItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 140;
	}

	@Override
	public boolean hasMinigame() {
		return true;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		for (BodyPart part : BodyPart.values()) {
			BodyPartData partData = data.part(part);
			if (quality >= 0.5f) {
				partData.setBleeding(partData.getBleeding().improve());
			}
			partData.heal(10.0f * quality);
			partData.addPain(-12.0f * quality);
			if (quality >= 0.7f) {
				partData.setInfection(partData.getInfection() - 20.0f);
			}
		}
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
