package com.casualtiesunknown.items;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;

import net.minecraft.server.network.ServerPlayerEntity;

/** Slow administration, restores a large amount of blood volume. */
public class BloodBagItem extends MedicalItem {

	public BloodBagItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 100;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		data.addBlood(1500.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
