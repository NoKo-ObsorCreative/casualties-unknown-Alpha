package com.casualtiesunknown.items;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.BodyPartData;
import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.medical.TreatmentTargets;

import net.minecraft.server.network.ServerPlayerEntity;

/** Stops bleeding on the most severely bleeding body part. Effectiveness scales with minigame quality. */
public class BandageItem extends MedicalItem {

	public BandageItem(Settings settings) {
		super(settings);
	}

	@Override
	public int getUseDurationTicks() {
		return 40;
	}

	@Override
	public boolean hasMinigame() {
		return true;
	}

	@Override
	public void applyTreatment(ServerPlayerEntity player, float quality) {
		PlayerHealthData data = dataOf(player);
		BodyPart target = TreatmentTargets.resolve(player.getUuid(), data, TreatmentTargets::autoPickBleeding);
		BodyPartData partData = data.part(target);

		if (quality >= 0.75f) {
			partData.setBleeding(partData.getBleeding().improve().improve());
		} else if (quality >= 0.35f) {
			partData.setBleeding(partData.getBleeding().improve());
		}
		// Low quality: bandage applied poorly, bleeding is unchanged (no wasted worsening).

		partData.heal(4.0f * quality);
		partData.addPain(-6.0f * quality);
		playTreatmentSound(player);
		syncAndCheckDeath(player, data);
	}
}
