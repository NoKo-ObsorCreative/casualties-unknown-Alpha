package com.casualtiesunknown.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Cancels {@link LivingEntity#heal(float)} for players, which is the single
 * choke point vanilla uses for: natural regeneration (from HungerManager),
 * the Regeneration status effect, the Instant Health status effect/potion,
 * and eating Golden Apples / Enchanted Golden Apples. Blocking it here
 * satisfies "prevent normal healing / golden apples / instant health
 * potions / vanilla healing mechanics" in one place instead of four.
 *
 * <p>The custom health system's own healing (from Bandages, Medkits, etc.)
 * never goes through vanilla {@code heal()} at all -- it mutates
 * {@link com.casualtiesunknown.components.BodyPartData} directly -- so it is
 * completely unaffected by this cancellation.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityHealMixin {

	@Inject(method = "heal", at = @At("HEAD"), cancellable = true)
	private void casualtiesunknown$blockVanillaHeal(float amount, CallbackInfo ci) {
		if ((Object) this instanceof PlayerEntity) {
			ci.cancel();
		}
	}
}
