package com.casualtiesunknown.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.casualtiesunknown.client.light.DynamicLightManager;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.LightType;

/**
 * Boosts {@link BlockRenderView#getLightLevel(LightType, BlockPos)} for
 * block light with whatever {@link DynamicLightManager} says should be
 * added at that position. Mixed into {@code BlockRenderView} (not
 * {@code World}) because {@code getLightLevel} is a default method
 * declared on that interface in Yarn 1.21.1 -- {@code World} itself never
 * overrides it, so a mixin targeting {@code World} can never find it. The
 * {@code instanceof ClientWorld} guard keeps this from ever touching
 * server-side light calculations, including the integrated server that
 * runs alongside the client in singleplayer.
 *
 * <p>Declared as an {@code interface} (not a {@code class}) because Sponge
 * Mixin requires the mixin type to match the target's kind -- a mixin
 * targeting an interface must itself be an interface, or it fails at
 * runtime with "@Mixin target type mismatch". Private interface methods
 * are valid Java since 9, which is what {@code compatibilityLevel
 * JAVA_21} in the mixin config allows here.
 *
 * <p>See {@link DynamicLightManager} for the troubleshooting note on this
 * being the most version-fragile file in the project.
 */
@Mixin(BlockRenderView.class)
public interface ClientWorldDynamicLightMixin {

	@Inject(method = "getLightLevel(Lnet/minecraft/world/LightType;Lnet/minecraft/util/math/BlockPos;)I",
			at = @At("RETURN"), cancellable = true)
	private void casualtiesunknown$boostDynamicLight(LightType type, BlockPos pos, CallbackInfoReturnable<Integer> cir) {
		if (type != LightType.BLOCK) {
			return;
		}
		if (!(((Object) this) instanceof ClientWorld)) {
			return;
		}
		int extra = DynamicLightManager.getExtraLight(pos);
		if (extra > cir.getReturnValue()) {
			cir.setReturnValue(extra);
		}
	}
}
