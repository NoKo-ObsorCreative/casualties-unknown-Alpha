package com.casualtiesunknown.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;

/**
 * Cancels vanilla's heart bar and hunger bar rendering -- they're replaced
 * entirely by the custom Blood/Pain/Exhaustion/Hydration HUD (see
 * com.casualtiesunknown.render.HealthHud).
 *
 * <p><b>Known risk / troubleshooting:</b> {@code InGameHud}'s private render
 * methods have been renamed a few times across Minecraft versions and Mixin
 * only validates them at runtime (a wrong name fails when the game
 * launches, not when Gradle builds). If you see a mixin-apply crash
 * mentioning this class on first launch: run {@code ./gradlew genSources},
 * open the generated {@code InGameHud.java} under
 * {@code build/loom-cache} / your IDE's library sources, find the methods
 * that draw the hearts and the hunger drumsticks, and update the
 * {@code method = "..."} values below (and the parameter types in the
 * {@code @At} target if using a full descriptor) to match.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

	@Inject(method = "renderHealthBar", at = @At("HEAD"), cancellable = true)
	private void casualtiesunknown$hideHealthBar(DrawContext context, net.minecraft.entity.player.PlayerEntity player,
			int x, int y, int lines, int regeneratingHeartIndex, float maxHealth, int currentHealth,
			int displayHealth, int absorption, boolean blinking, CallbackInfo ci) {
		ci.cancel();
	}

	@Inject(method = "renderFood", at = @At("HEAD"), cancellable = true)
	private void casualtiesunknown$hideFoodBar(DrawContext context, net.minecraft.entity.player.PlayerEntity player,
			int x, int y, CallbackInfo ci) {
		ci.cancel();
	}
}
