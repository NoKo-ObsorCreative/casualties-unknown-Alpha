package com.casualtiesunknown.client;

import com.casualtiesunknown.client.input.KeyBindings;
import com.casualtiesunknown.client.light.DynamicLightManager;
import com.casualtiesunknown.client.network.ClientNetworking;
import com.casualtiesunknown.gui.TreatmentMinigameScreen;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.render.HealthHud;
import com.casualtiesunknown.util.ModConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;

/**
 * Client-only entrypoint. Everything registered here is stripped from a
 * dedicated server build by Fabric Loader automatically (declared under
 * the "client" entrypoint in fabric.mod.json), so none of this needs
 * {@code @Environment(EnvType.CLIENT)} annotations itself.
 */
public final class CasualtiesUnknownClient implements ClientModInitializer {

	private int breathingCooldown;

	@Override
	public void onInitializeClient() {
		ModConstants.LOGGER.info("Initializing Casualties Unknown client");

		ClientNetworking.register();
		KeyBindings.register();
		HealthHud.register();

		// Bridge MedicalItem's common-code hook to the actual client-only screen,
		// without MedicalItem ever needing to reference a client-only class itself.
		MedicalItem.MINIGAME_LAUNCHER = TreatmentMinigameScreen::open;

		ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
	}

	private void onClientTick(MinecraftClient client) {
		if (client.player == null || client.world == null) {
			return;
		}

		DynamicLightManager.tick(client.player);

		// If the active item stopped being used (finished, interrupted by
		// damage, or switched away) while a minigame screen is open for a
		// *different* reason than the player finishing it themselves, the
		// vanilla use-item state simply becomes irrelevant to us -- the
		// minigame screen manages its own lifecycle via close()/resolve().
		// This tick is only used for the ambient "heavy breathing" cue below.

		float pain = ClientHealthCache.get().getGlobalPain();
		if (pain > 60) {
			if (breathingCooldown <= 0) {
				client.player.playSound(SoundEvents.ENTITY_PLAYER_BREATH, 0.5f, 0.8f);
				breathingCooldown = Math.round(40 - Math.min(20, (pain - 60) / 2f));
			} else {
				breathingCooldown--;
			}
		} else {
			breathingCooldown = 0;
		}
	}
}
