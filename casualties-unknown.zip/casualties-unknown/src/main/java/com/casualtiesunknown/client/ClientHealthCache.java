package com.casualtiesunknown.client;

import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.components.PlayerHealthData;

import net.minecraft.nbt.NbtCompound;

/**
 * Client-side, read-only cache of the local player's
 * {@link PlayerHealthData}, updated whenever a
 * {@link com.casualtiesunknown.network.HealthSyncPayload} arrives. Both the
 * Injuries Menu and the custom HUD read from here -- neither ever touches
 * a server-side attachment directly, since attachments aren't automatically
 * synced by Fabric, only by our own packet.
 */
public final class ClientHealthCache {

	private static PlayerHealthData data = PlayerHealthData.createDefault();

	/** Body part the player last clicked "Focus" on in the Injuries Menu, purely for highlighting the UI. */
	private static BodyPart uiFocusedPart;

	private ClientHealthCache() {
	}

	public static PlayerHealthData get() {
		return data;
	}

	public static void update(NbtCompound nbt) {
		data = PlayerHealthData.fromNbt(nbt);
	}

	public static BodyPart getUiFocusedPart() {
		return uiFocusedPart;
	}

	public static void setUiFocusedPart(BodyPart part) {
		uiFocusedPart = part;
	}
}
