package com.casualtiesunknown.client.input;

import org.lwjgl.glfw.GLFW;

import com.casualtiesunknown.gui.InjuriesScreen;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/** Registers the "Open Injuries Menu" keybind, defaulting to M. Fully rebindable via the normal Controls screen. */
public final class KeyBindings {

	public static KeyBinding openInjuriesMenu;

	private KeyBindings() {
	}

	public static void register() {
		openInjuriesMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.casualtiesunknown.injuries_menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_M,
				"key.category.casualtiesunknown"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openInjuriesMenu.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new InjuriesScreen());
				}
			}
		});
	}
}
