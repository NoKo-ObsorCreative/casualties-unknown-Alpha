package com.casualtiesunknown.client.network;

import com.casualtiesunknown.client.ClientHealthCache;
import com.casualtiesunknown.components.BodyPart;
import com.casualtiesunknown.network.HealthSyncPayload;
import com.casualtiesunknown.network.SelectTreatmentTargetPayload;
import com.casualtiesunknown.network.TreatmentResultPayload;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.util.Identifier;

/** Client-only networking: receives health syncs, sends focus/treatment-result packets. */
public final class ClientNetworking {

	private ClientNetworking() {
	}

	public static void register() {
		ClientPlayNetworking.registerGlobalReceiver(HealthSyncPayload.ID, (payload, context) ->
				context.client().execute(() -> ClientHealthCache.update(payload.data())));
	}

	public static void sendFocusTarget(BodyPart part) {
		if (ClientPlayNetworking.canSend(SelectTreatmentTargetPayload.ID)) {
			ClientPlayNetworking.send(new SelectTreatmentTargetPayload(part));
		}
	}

	public static void sendTreatmentResult(Identifier itemId, float quality) {
		if (ClientPlayNetworking.canSend(TreatmentResultPayload.ID)) {
			ClientPlayNetworking.send(new TreatmentResultPayload(itemId, quality));
		}
	}
}
