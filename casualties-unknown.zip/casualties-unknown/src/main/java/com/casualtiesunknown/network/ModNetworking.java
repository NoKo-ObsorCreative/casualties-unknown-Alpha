package com.casualtiesunknown.network;

import com.casualtiesunknown.components.PlayerHealthData;
import com.casualtiesunknown.events.HealthSyncHelper;
import com.casualtiesunknown.medical.MedicalItem;
import com.casualtiesunknown.medical.TreatmentTargets;
import com.casualtiesunknown.registry.ModAttachmentTypes;
import com.casualtiesunknown.util.ModConstants;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;

/**
 * Registers every custom payload type (must happen identically on both
 * sides, so both the client and server can (de)serialize them) and the
 * server-side receivers for the two client-to-server payloads.
 * Client-side receiving is wired up separately in
 * com.casualtiesunknown.client.network.ClientNetworking, which is only
 * ever loaded on the client physical side.
 */
public final class ModNetworking {

	private ModNetworking() {
	}

	/** Call from the common mod initializer, on both logical sides. */
	public static void registerPayloadTypes() {
		PayloadTypeRegistry.playS2C().register(HealthSyncPayload.ID, HealthSyncPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(SelectTreatmentTargetPayload.ID, SelectTreatmentTargetPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(TreatmentResultPayload.ID, TreatmentResultPayload.CODEC);
	}

	/** Call from the common mod initializer; registers the server-side handlers for C2S payloads. */
	public static void registerServerReceivers() {
		ServerPlayNetworking.registerGlobalReceiver(SelectTreatmentTargetPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			context.server().execute(() -> TreatmentTargets.setFocus(player.getUuid(), payload.part()));
		});

		ServerPlayNetworking.registerGlobalReceiver(TreatmentResultPayload.ID, (payload, context) -> {
			ServerPlayerEntity player = context.player();
			context.server().execute(() -> handleTreatmentResult(player, payload));
		});

		ModConstants.LOGGER.debug("Registered Casualties Unknown server packet receivers");
	}

	private static void handleTreatmentResult(ServerPlayerEntity player, TreatmentResultPayload payload) {
		Item item = Registries.ITEM.get(payload.itemId());
		if (!(item instanceof MedicalItem medicalItem)) {
			ModConstants.LOGGER.warn("{} sent a treatment result for a non-medical item {}", player.getName().getString(), payload.itemId());
			return;
		}

		// Re-validate: the player must actually be holding this item, so a
		// modified client can't fabricate a treatment out of thin air.
		Hand holdingHand = null;
		if (player.getMainHandStack().getItem() == item) {
			holdingHand = Hand.MAIN_HAND;
		} else if (player.getOffHandStack().getItem() == item) {
			holdingHand = Hand.OFF_HAND;
		}
		if (holdingHand == null) {
			return;
		}

		float quality = Math.max(0.0f, Math.min(1.0f, payload.quality()));
		medicalItem.applyTreatment(player, quality);

		if (medicalItem.isConsumable()) {
			ItemStack stack = player.getStackInHand(holdingHand);
			MedicalItem.consumeOne(stack, player);
		}

		PlayerHealthData data = player.getAttachedOrCreate(ModAttachmentTypes.HEALTH_DATA);
		HealthSyncHelper.markDirty(player.getUuid());
		if (data.isDead()) {
			player.kill(player.getServerWorld());
		}
	}
}
