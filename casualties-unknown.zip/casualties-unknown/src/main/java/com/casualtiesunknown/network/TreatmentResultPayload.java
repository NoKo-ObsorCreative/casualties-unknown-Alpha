package com.casualtiesunknown.network;

import com.casualtiesunknown.util.ModConstants;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Client -> server. Sent when a treatment minigame (see
 * com.casualtiesunknown.medical.MedicalItem / the client TreatmentMinigameScreen)
 * concludes, either because the player hit the target, missed, or a simple
 * (non-minigame) item finished its hold duration with a fixed quality of 1.0.
 *
 * <p>The server treats {@code quality} as a hint only -- it re-validates that
 * the sending player actually holds a matching {@code itemId} stack before
 * applying any effect or consuming an item, so a modified client cannot
 * claim a perfect score without the item actually being in hand.
 */
public record TreatmentResultPayload(Identifier itemId, float quality) implements CustomPayload {

	public static final CustomPayload.Id<TreatmentResultPayload> ID =
			new CustomPayload.Id<>(ModConstants.id("treatment_result"));

	public static final PacketCodec<RegistryByteBuf, TreatmentResultPayload> CODEC = PacketCodec.tuple(
			Identifier.PACKET_CODEC, TreatmentResultPayload::itemId,
			PacketCodecs.FLOAT, TreatmentResultPayload::quality,
			TreatmentResultPayload::new
	);

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}
