package com.casualtiesunknown.network;

import com.casualtiesunknown.util.ModConstants;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/**
 * Server -> owning client. Carries a full NBT snapshot of the player's
 * {@link com.casualtiesunknown.components.PlayerHealthData}. Sent on join
 * and whenever the server-side data is marked dirty (see
 * com.casualtiesunknown.events.ServerTickHandler), coalesced to at most
 * once per tick per player to keep packet volume low.
 */
public record HealthSyncPayload(NbtCompound data) implements CustomPayload {

	public static final CustomPayload.Id<HealthSyncPayload> ID =
			new CustomPayload.Id<>(ModConstants.id("health_sync"));

	public static final PacketCodec<RegistryByteBuf, HealthSyncPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.NBT_COMPOUND, HealthSyncPayload::data,
			HealthSyncPayload::new
	);

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}
