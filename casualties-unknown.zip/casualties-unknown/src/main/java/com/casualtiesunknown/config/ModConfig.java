package com.casualtiesunknown.config;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.casualtiesunknown.util.ModConstants;

import net.fabricmc.loader.api.FabricLoader;

/**
 * Simple JSON-file configuration. Deliberately dependency-free (uses Gson,
 * which already ships on Minecraft's classpath) rather than pulling in
 * Cloth Config or similar, per the "Fabric API only unless absolutely
 * necessary" requirement.
 *
 * <p>All fields are public and mutable so an in-game config screen (not
 * included here, see README) can bind directly to them.
 */
public final class ModConfig {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final String FILE_NAME = ModConstants.MOD_ID + ".json";

	private static ModConfig instance;

	// --- Feature toggles ---
	public boolean enableDynamicLights = true;
	public boolean enableLimbDamage = true;
	public boolean enableInfection = true;
	public boolean enableBlood = true;
	public boolean enableShock = true;

	// --- Difficulty / rate multipliers ---
	public float difficultyMultiplier = 1.0f;
	public float healingSpeedMultiplier = 1.0f;
	public float bloodLossRateMultiplier = 1.0f;
	public float exhaustionRateMultiplier = 1.0f;

	// --- Death behavior ---
	/** If true, all injuries/blood/etc. reset to full on respawn. If false, they persist (hardcore-style). */
	public boolean resetHealthOnDeath = true;

	// --- HUD ---
	public String hudPosition = "TOP_LEFT"; // TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
	public float guiScale = 1.0f;

	// --- Keybinds (translated into KeyBinding defaults; changing these here only
	// changes the *default*, players can still rebind in the normal Controls menu) ---
	public String injuriesMenuKey = "key.keyboard.m";

	public static ModConfig get() {
		if (instance == null) {
			instance = load();
		}
		return instance;
	}

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	private static ModConfig load() {
		Path path = configPath();
		if (Files.exists(path)) {
			try (Reader reader = Files.newBufferedReader(path)) {
				ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
				if (loaded != null) {
					return loaded;
				}
			} catch (IOException e) {
				ModConstants.LOGGER.error("Failed to read config, using defaults", e);
			}
		}
		ModConfig fresh = new ModConfig();
		fresh.save();
		return fresh;
	}

	public void save() {
		Path path = configPath();
		try {
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException e) {
			ModConstants.LOGGER.error("Failed to save config", e);
		}
	}
}
